# Flash0/1/2/3 Dumper
* Move `ARK4.BIN` from `psp_flash_dumper` to `PSP/SAVEDATA/ARK_01234/`
* Run `ARK Loader`

* It may not exit cleanly, it's fine it still dumped fully.


# idstorage dumper
* Move `ARK4.BIN` from `idstorage_dumper` to `PSP/SAVEDATA/ARK_01234/`
* Run `ARK Loader`

* It may not exit cleanly, it's fine it still dumped fully.
